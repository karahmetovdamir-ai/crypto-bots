package com.example.data

import org.json.JSONObject

data class KlineData(
    val closePrice: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val isFinal: Boolean,
    val timestamp: Long
) {
    companion object {
        fun fromJson(jsonStr: String): KlineData? {
            return try {
                val obj = JSONObject(jsonStr)
                if (obj.getString("e") == "kline") {
                    val k = obj.getJSONObject("k")
                    KlineData(
                        closePrice = k.getString("c").toDouble(),
                        highPrice = k.getString("h").toDouble(),
                        lowPrice = k.getString("l").toDouble(),
                        isFinal = k.getBoolean("x"),
                        timestamp = obj.getLong("E")
                    )
                } else {
                    null
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}
