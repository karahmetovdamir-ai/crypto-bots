package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object BotState {
    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _isWebSocketConnected = MutableStateFlow(false)
    val isWebSocketConnected: StateFlow<Boolean> = _isWebSocketConnected.asStateFlow()

    private val _currentPrice = MutableStateFlow(0.0)
    val currentPrice: StateFlow<Double> = _currentPrice.asStateFlow()

    // Price direction: 1 for up, -1 for down, 0 for unchanged
    private val _priceDirection = MutableStateFlow(0)
    val priceDirection: StateFlow<Int> = _priceDirection.asStateFlow()

    private val _liveRsi = MutableStateFlow<Double?>(null)
    val liveRsi: StateFlow<Double?> = _liveRsi.asStateFlow()

    private val _liveEma = MutableStateFlow<Double?>(null)
    val liveEma: StateFlow<Double?> = _liveEma.asStateFlow()

    private val _lastSignalType = MutableStateFlow<String?>(null)
    val lastSignalType: StateFlow<String?> = _lastSignalType.asStateFlow()

    private val _lastSignalPrice = MutableStateFlow<Double?>(null)
    val lastSignalPrice: StateFlow<Double?> = _lastSignalPrice.asStateFlow()

    fun setServiceRunning(running: Boolean) {
        _isServiceRunning.value = running
    }

    fun setWebSocketConnected(connected: Boolean) {
        _isWebSocketConnected.value = connected
    }

    fun updatePrice(price: Double) {
        val previous = _currentPrice.value
        _priceDirection.value = when {
            price > previous -> 1
            price < previous -> -1
            else -> 0
        }
        _currentPrice.value = price
    }

    fun updateIndicators(rsi: Double?, ema: Double?) {
        _liveRsi.value = rsi
        _liveEma.value = ema
    }

    fun setLastSignal(type: String, price: Double) {
        _lastSignalType.value = type
        _lastSignalPrice.value = price
    }

    fun resetState() {
        _currentPrice.value = 0.0
        _priceDirection.value = 0
        _liveRsi.value = null
        _liveEma.value = null
        _lastSignalType.value = null
        _lastSignalPrice.value = null
        _isWebSocketConnected.value = false
    }
}
