package com.example.data

import kotlinx.coroutines.flow.Flow

class SignalRepository(private val signalDao: SignalDao) {
    val allSignals: Flow<List<SignalEntity>> = signalDao.getAllSignals()

    suspend fun insertSignal(signal: SignalEntity) {
        signalDao.insertSignal(signal)
    }

    suspend fun clearAllSignals() {
        signalDao.clearAllSignals()
    }
}
