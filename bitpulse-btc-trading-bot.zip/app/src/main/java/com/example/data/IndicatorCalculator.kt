package com.example.data

object IndicatorCalculator {

    /**
     * Calculates the EMA(period) of the given list of prices.
     * Formula: Multiplier = 2 / (Period + 1)
     * Current EMA = (Close Price - Previous EMA) * Multiplier + Previous EMA.
     */
    fun calculateEma(prices: List<Double>, period: Int = 14): Double? {
        if (prices.size < period) return null
        val multiplier = 2.0 / (period + 1)
        
        // Initial EMA is the first price (or average of first 'period' prices).
        // Standard definition starts with the first price as the seed EMA.
        var ema = prices[0]
        for (i in 1 until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    /**
     * Calculates the RSI(period) using Welles Wilder's smoothing method.
     * We need at least (period + 1) data points to compute the first RSA.
     */
    fun calculateRsi(prices: List<Double>, period: Int = 14): Double? {
        if (prices.size <= period) return null
        
        val gains = DoubleArray(prices.size - 1)
        val losses = DoubleArray(prices.size - 1)
        
        for (i in 1 until prices.size) {
            val diff = prices[i] - prices[i - 1]
            gains[i - 1] = if (diff > 0) diff else 0.0
            losses[i - 1] = if (diff < 0) -diff else 0.0
        }
        
        // Calculate initial average gain and loss over the first 'period' elements
        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 0 until period) {
            avgGain += gains[i]
            avgLoss += losses[i]
        }
        avgGain /= period
        avgLoss /= period
        
        // Apply Welles Wilder's smoothing for subsequent elements
        for (i in period until gains.size) {
            avgGain = (avgGain * (period - 1) + gains[i]) / period
            avgLoss = (avgLoss * (period - 1) + losses[i]) / period
        }
        
        if (avgLoss == 0.0) {
            return if (avgGain == 0.0) 50.0 else 100.0
        }
        
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }
}
