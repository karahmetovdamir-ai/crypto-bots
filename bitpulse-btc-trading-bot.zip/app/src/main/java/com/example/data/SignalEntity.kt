package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val type: String, // "CALL" or "PUT"
    val asset: String = "BTC/USDT",
    val price: Double,
    val rsiValue: Double,
    val emaValue: Double
)
