package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.BotState
import com.example.data.IndicatorCalculator
import com.example.data.KlineData
import com.example.data.SignalEntity
import com.example.data.SignalRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import java.util.Locale
import java.util.concurrent.TimeUnit

class SignalBotService : Service() {

    companion object {
        private const val TAG = "SignalBotService"
        private const val ONGOING_NOTIFICATION_ID = 1001
        private const val SIGNAL_ALERT_NOTIFICATION_ID = 1002
        private const val CHANNEL_ONGOING_ID = "signal_bot_ongoing_channel"
        private const val CHANNEL_ALERT_ID = "signal_bot_alert_channel"

        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private lateinit var repository: SignalRepository
    private val client = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .build()
    
    private var webSocket: WebSocket? = null
    private val closedCandles = mutableListOf<Double>()
    
    // Limits
    private val MAX_CANDLES_HISTORY = 50
    
    // Cooldown limits to prevent multiple identical alerts inside 60 seconds (1 minute kline period)
    private var lastSignalTime = 0L
    private var lastSignalType: String? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service onCreate")
        val signalDao = AppDatabase.getDatabase(this).signalDao()
        repository = SignalRepository(signalDao)
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        Log.d(TAG, "onStartCommand action: $action")
        
        if (action == ACTION_STOP) {
            stopServiceCleanly()
            return START_NOT_STICKY
        }
        
        // Start Foreground
        BotState.resetState()
        BotState.setServiceRunning(true)
        startForegroundServiceCompat()
        
        // Start Bot background processing
        bootBot()

        return START_STICKY
    }

    private fun bootBot() {
        serviceScope.launch(Dispatchers.IO) {
            // Step 1: Initialize historical data
            fetchHistoricalCandles()
            
            // Step 2: Connect WebSocket with retry mechanism
            connectWebSocket()
        }
    }

    private suspend fun fetchHistoricalCandles() {
        try {
            Log.d(TAG, "Fetching initial 50 historical closed minutes candles...")
            val request = Request.Builder()
                .url("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=50")
                .build()
            
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful && response.body != null) {
                    val bodyString = response.body!!.string()
                    val rootArray = JSONArray(bodyString)
                    
                    synchronized(closedCandles) {
                        closedCandles.clear()
                        // The elements of the kline array are itself arrays.
                        // Index 4 is the Close price (String)
                        // Note: The last element of this array is the currently *active* 1m candle (which is not final).
                        // Let's only take completed candles (all except the last one).
                        val size = rootArray.length()
                        val limit = if (size > 0) size - 1 else 0
                        
                        for (i in 0 until limit) {
                            val candleArray = rootArray.getJSONArray(i)
                            val closePrice = candleArray.getString(4).toDouble()
                            closedCandles.add(closePrice)
                        }
                    }
                    Log.d(TAG, "Successfully loaded ${closedCandles.size} historical minutes candles into cache.")
                } else {
                    Log.e(TAG, "Binance Historical Candlesticks API failed. Response: ${response.code}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching historical candlesticks from REST API", e)
        }
    }

    private fun connectWebSocket() {
        val request = Request.Builder()
            .url("wss://stream.binance.com:9443/ws/btcusdt@kline_1m")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d(TAG, "WebSocket connected successfully.")
                BotState.setWebSocketConnected(true)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                processKlineMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closing: $reason")
                BotState.setWebSocketConnected(false)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closed: $reason")
                BotState.setWebSocketConnected(false)
                triggerWebSocketReconnection()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket Failure: ${t.message}", t)
                BotState.setWebSocketConnected(false)
                triggerWebSocketReconnection()
            }
        })
    }

    private var isReconnecting = false
    private fun triggerWebSocketReconnection() {
        if (!BotState.isServiceRunning.value || isReconnecting) return
        isReconnecting = true
        serviceScope.launch(Dispatchers.IO) {
            var attempt = 1
            while (BotState.isServiceRunning.value && !BotState.isWebSocketConnected.value) {
                val delayTime = (1L shl attempt) * 1000L // Exponential backoff: 2s, 4s, 8s, 16s...
                val clampedDelay = delayTime.coerceAtMost(60000L) // Limit to 60s
                Log.d(TAG, "Reconnecting WebSocket in ${clampedDelay / 1000} seconds (Attempt $attempt)...")
                delay(clampedDelay)
                
                if (BotState.isServiceRunning.value && !BotState.isWebSocketConnected.value) {
                    try {
                        webSocket?.cancel()
                        connectWebSocket()
                    } catch (e: Exception) {
                        Log.e(TAG, "Reconnect try failed: ${e.message}")
                    }
                }
                attempt++
            }
            isReconnecting = false
        }
    }

    private fun processKlineMessage(text: String) {
        val kline = KlineData.fromJson(text) ?: return
        
        // 1. Update live price & connection indicators
        BotState.updatePrice(kline.closePrice)
        
        val liveClose = kline.closePrice
        
        // 2. Build candle arrays for indicator calculation
        val pricesForIndicator = mutableListOf<Double>()
        synchronized(closedCandles) {
            pricesForIndicator.addAll(closedCandles)
        }
        
        // Use the live actual tick as the temp current element
        val pricesWithLiveTick = pricesForIndicator + liveClose
        
        // 3. Compute indicators
        val rsiLive = IndicatorCalculator.calculateRsi(pricesWithLiveTick)
        val emaLive = IndicatorCalculator.calculateEma(pricesWithLiveTick)
        
        BotState.updateIndicators(rsiLive, emaLive)
        
        // 4. Update Ongoing Persistent Notification State
        updateOngoingNotification(liveClose, rsiLive, emaLive)
        
        // 5. Evaluate trading signal logic
        if (rsiLive != null && emaLive != null) {
            // To compute a safe "hook", we compare indicators on the completed past values
            // against indicators including the live active ticker!
            val rsiPrev = IndicatorCalculator.calculateRsi(pricesForIndicator)
            
            if (rsiPrev != null) {
                evaluateSignals(liveClose, rsiPrev, rsiLive, emaLive)
            }
        }
        
        // 6. Handle Candle closure/finalization
        if (kline.isFinal) {
            Log.d(TAG, "Candle CLOSED! Final Price: ${kline.closePrice}")
            synchronized(closedCandles) {
                closedCandles.add(kline.closePrice)
                if (closedCandles.size > MAX_CANDLES_HISTORY) {
                    closedCandles.removeAt(0)
                }
            }
        }
    }

    private fun evaluateSignals(currentPrice: Double, rsiPrev: Double, rsiCurr: Double, currentEma: Double) {
        val currentTime = System.currentTimeMillis()
        
        // Signal verification rules
        // CALL Signal: currentPrice > EMA AND rsiPrev <= 30 AND rsiCurr > rsiPrev (hook up)
        val isCallTriggered = (currentPrice > currentEma) && (rsiPrev <= 30.0) && (rsiCurr > rsiPrev)
        
        // PUT Signal: currentPrice < EMA AND rsiPrev >= 70 AND rsiCurr < rsiPrev (hook down)
        val isPutTriggered = (currentPrice < currentEma) && (rsiPrev >= 70.0) && (rsiCurr < rsiPrev)
        
        if (isCallTriggered || isPutTriggered) {
            val signalType = if (isCallTriggered) "CALL" else "PUT"
            
            // Cooldown mechanism: prevent slamming alerts for the same condition inside 45 seconds (candle window)
            if (lastSignalType == signalType && (currentTime - lastSignalTime) < 45000L) {
                return
            }
            
            lastSignalTime = currentTime
            lastSignalType = signalType
            BotState.setLastSignal(signalType, currentPrice)
            
            // Record target metrics
            triggerSignalAlert(signalType, currentPrice, rsiCurr, currentEma)
        }
    }

    private fun triggerSignalAlert(type: String, price: Double, rsi: Double, ema: Double) {
        val timestamp = System.currentTimeMillis()
        
        // 1. Insert into persistent Room database
        serviceScope.launch(Dispatchers.IO) {
            try {
                val signal = SignalEntity(
                    timestamp = timestamp,
                    type = type,
                    price = price,
                    rsiValue = rsi,
                    emaValue = ema
                )
                repository.insertSignal(signal)
                Log.d(TAG, "Inserted new $type signal to local database @ \$$price")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to persist signal in database", e)
            }
        }
        
        // 2. Play high priority sound alert notification
        postHighPriorityNotification(type, price, rsi)
    }

    private fun postHighPriorityNotification(type: String, price: Double, rsi: Double) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        
        val contentText = String.format(
            Locale.US,
            "BTC/USDT @ $%.2f - RSI: %.2f (Direction: %s)",
            price, rsi, type
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ALERT_ID)
            .setContentTitle("New BOT Signal: **$type** 🔥")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(soundUri)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // Generate a new unique ID per alert to queue notifications instead of overwriting them
        val alertId = (SIGNAL_ALERT_NOTIFICATION_ID + (System.currentTimeMillis() % 100000)).toInt()
        notificationManager.notify(alertId, notification)
    }

    private fun startForegroundServiceCompat() {
        val notification = buildOngoingNotification(0.0, null, null)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    ONGOING_NOTIFICATION_ID, 
                    notification, 
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(ONGOING_NOTIFICATION_ID, notification)
            }
            Log.d(TAG, "startForeground completed.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed starting foreground service", e)
        }
    }

    private fun buildOngoingNotification(price: Double, rsi: Double?, ema: Double?): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val priceStr = if (price > 0) String.format(Locale.US, "$%.2f", price) else "Loading..."
        val rsiStr = if (rsi != null) String.format(Locale.US, "%.1f", rsi) else "calculating"
        val emaStr = if (ema != null) String.format(Locale.US, "$%.1f", ema) else "calculating"

        return NotificationCompat.Builder(this, CHANNEL_ONGOING_ID)
            .setContentTitle("BTC/USDT Trading Signal Bot Active")
            .setContentText("Live Price: $priceStr | RSI(14): $rsiStr | EMA(14): $emaStr")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateOngoingNotification(price: Double, rsi: Double?, ema: Double?) {
        val notification = buildOngoingNotification(price, rsi, ema)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(ONGOING_NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // 1. Ongoing Service Channel
            val ongoingChannel = NotificationChannel(
                CHANNEL_ONGOING_ID,
                "Ongoing Bot Updates",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live BTC/USDT values computed in background"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(ongoingChannel)

            // 2. High Priority Signal Alert Channel
            val alertChannel = NotificationChannel(
                CHANNEL_ALERT_ID,
                "Trading Signal Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Rings/notifies when a BUY (CALL) or SELL (PUT) entry triggers"
                enableLights(true)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(alertChannel)
        }
    }

    private fun stopServiceCleanly() {
        Log.d(TAG, "Stopping service cleanly...")
        BotState.setServiceRunning(false)
        BotState.resetState()
        try {
            webSocket?.close(1000, "Service stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error closing WebSocket on destroy", e)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        Log.d(TAG, "Service onDestroy")
        BotState.setServiceRunning(false)
        try {
            webSocket?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Error canceling Web socket in onDestroy", e)
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
