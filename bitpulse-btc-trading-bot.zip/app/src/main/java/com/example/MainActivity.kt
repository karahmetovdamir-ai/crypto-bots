package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.SignalEntity
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.SignalBotViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        val msg = if (isGranted) "Alert Notifications activated!" else "Notification alerts skipped."
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Dynamic notification permission check for Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF0B0E11) // High-contrast clean dark space background (Binance style)
                ) { innerPadding ->
                    TradingBotDashboard(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradingBotDashboard(
    modifier: Modifier = Modifier,
    viewModel: SignalBotViewModel = viewModel()
) {
    val context = LocalContext.current
    
    // Collecting reactive states beautifully
    val isRunning by viewModel.isServiceRunning.collectAsStateWithLifecycle()
    val isConnected by viewModel.isWebSocketConnected.collectAsStateWithLifecycle()
    val currentPrice by viewModel.currentPrice.collectAsStateWithLifecycle()
    val priceDirection by viewModel.priceDirection.collectAsStateWithLifecycle()
    val rsi by viewModel.liveRsi.collectAsStateWithLifecycle()
    val ema by viewModel.liveEma.collectAsStateWithLifecycle()
    val signalsLog by viewModel.signals.collectAsStateWithLifecycle()

    // 1. Theme Color Tokens
    val colorBackground = Color(0xFF0B0E11)
    val colorCardBg = Color(0xFF1E2329)
    val colorAccentGreen = Color(0xFF0ECB81)
    val colorAccentRed = Color(0xFFF6465D)
    val colorGrayText = Color(0xFF848E9C)
    val colorGolden = Color(0xFFF0B90B)
    
    // Dynamic price coloring based on tick direction (flash green, red, or white)
    val animatedPriceColor by animateColorAsState(
        targetValue = when (priceDirection) {
            1 -> colorAccentGreen
            -1 -> colorAccentRed
            else -> Color(0xFFEAECEF)
        },
        animationSpec = tween(durationMillis = 200),
        label = "priceColor"
    )

    // Pulsing animation for active indicators
    val infiniteTransition = rememberInfiniteTransition(label = "pulsingIndicator")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colorBackground)
            .padding(horizontal = 16.dp)
    ) {
        
        // TOP APP HEADER
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = "BTC SIGNAL BOT",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    // Connection Pulsing Hub Dot
                    val statusColor = when {
                        !isRunning -> colorGrayText
                        isConnected -> colorAccentGreen
                        else -> colorAccentRed
                    }
                    val statusText = when {
                        !isRunning -> "Bot Stopped"
                        isConnected -> "Live Feed"
                        else -> "Connecting"
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(statusColor.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .alpha(if (isRunning) pulseAlpha else 1.0f)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusText.uppercase(),
                            color = statusColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent,
                titleContentColor = Color.White
            ),
            actions = {
                if (signalsLog.isNotEmpty()) {
                    IconButton(
                        onClick = { viewModel.clearLogHistory() },
                        modifier = Modifier.testTag("clear_logs_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear logs journal",
                            tint = colorAccentRed
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        // RESPONSIVE SCREEN WRAPPER FOR TABLETS (Centers beautifully in compact constraints)
        Column(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .widthIn(max = 600.dp) // tablet-friendly boundary
                .weight(1.0f)
        ) {
            
            // MAIN MARKET DATA DISPLAY TICKET
            Card(
                colors = CardDefaults.cardColors(containerColor = colorCardBg),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF2B3139)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "BTC/USDT MINUTE VALUE",
                        color = colorGrayText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    // Huge live price readout
                    val displayPrice = if (currentPrice > 0) {
                        String.format(Locale.US, "$%,.2f", currentPrice)
                    } else if (isRunning) {
                        "Awaiting Tick..."
                    } else {
                        "Bot Offline"
                    }
                    
                    Text(
                        text = displayPrice,
                        color = if (currentPrice > 0) animatedPriceColor else colorGrayText,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("live_price_text")
                    )
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    // Signal state badge helper
                    Row(
                        modifier = Modifier
                            .padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShowChart,
                            contentDescription = "Active Indicator Chart",
                            tint = colorGolden,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRunning) "Binance Stream Active (1m klines)" else "Start bot to begin calculations",
                            fontSize = 11.sp,
                            color = colorGrayText,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // INDEPENDENT STATS CARDS PANEL
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // CARD 1: RELATIVE STRENGTH INDEX (RSI)
                Card(
                    colors = CardDefaults.cardColors(containerColor = colorCardBg),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF2B3139)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "RSI (14) WILDER",
                            color = colorGrayText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        val rsiReady = rsi != null
                        val rsiVal = rsi ?: 50.0
                        val rsiColor = when {
                            !rsiReady -> Color.White
                            rsiVal <= 30.0 -> colorAccentGreen // Oversold hook trigger region
                            rsiVal >= 70.0 -> colorAccentRed // Overbought hook trigger region
                            else -> Color.White
                        }
                        
                        val rsiLabel = when {
                            !rsiReady -> "CALCULATING"
                            rsiVal <= 30.0 -> "OVERSOLD 🔥"
                            rsiVal >= 70.0 -> "OVERBOUGHT ⚠️"
                            else -> "NEUTRAL"
                        }

                        Text(
                            text = if (rsiReady) String.format(Locale.US, "%.2f", rsiVal) else "...",
                            color = rsiColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = rsiLabel,
                            color = if (rsiReady) rsiColor.copy(alpha = 0.8f) else colorGrayText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // CARD 2: EMA (14)
                Card(
                    colors = CardDefaults.cardColors(containerColor = colorCardBg),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF2B3139)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "EMA (14) IND",
                            color = colorGrayText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        val emaReady = ema != null
                        val emaValue = ema ?: 0.0
                        val currentBtPrice = currentPrice
                        
                        val isBullish = emaReady && currentBtPrice > emaValue
                        val trendColor = if (isBullish) colorAccentGreen else colorAccentRed
                        val trendText = when {
                            !emaReady -> "CALCULATING"
                            isBullish -> "BULLISH TREND"
                            else -> "BEARISH TREND"
                        }

                        Text(
                            text = if (emaReady) String.format(Locale.US, "$%,.1f", emaValue) else "...",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = trendText,
                            color = if (emaReady) trendColor else colorGrayText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // MAIN COMMAND BUTTON BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // START BOT KEY
                Button(
                    onClick = { viewModel.startBot(context) },
                    enabled = !isRunning,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colorAccentGreen,
                        contentColor = Color.Black,
                        disabledContainerColor = Color(0xFF13362a)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("start_bot_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play symbol")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "START BOT",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // STOP BOT KEY
                Button(
                    onClick = { viewModel.stopBot(context) },
                    enabled = isRunning,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colorAccentRed,
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFF3b1c20)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("stop_bot_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop symbol")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "STOP BOT",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // SIGNAL JOURNAL ENTRIES TITLE ROW
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "TRIGGERED SIGNAL LOG",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                
                // Count Shield Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(colorGolden.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${signalsLog.size} TRADES",
                        color = colorGolden,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // COMPOSABLE LIVE JOURNAL VIEW LIST (LAZYCOLUMN)
            if (signalsLog.isEmpty()) {
                // Polished Empty State
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(colorCardBg.copy(alpha = 0.4f))
                        .border(1.dp, Color(0xFF2B3139).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(24.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "No Signals Alert",
                            tint = colorGrayText.copy(alpha = 0.6f),
                            modifier = Modifier
                                .size(48.dp)
                                .alpha(pulseAlpha)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "No Trading Signals Yet",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Press START BOT above. The background service will run real-time Welles Wilder calculations on the 1-minute BTC feed.",
                            color = colorGrayText,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("signal_history_list")
                ) {
                    items(
                        items = signalsLog,
                        key = { it.id }
                    ) { signal ->
                        SignalCard(
                            signal = signal,
                            accentGreen = colorAccentGreen,
                            accentRed = colorAccentRed,
                            cardBg = colorCardBg,
                            grayText = colorGrayText
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SignalCard(
    signal: SignalEntity,
    accentGreen: Color,
    accentRed: Color,
    cardBg: Color,
    grayText: Color
) {
    val isCall = signal.type == "CALL"
    val themeColor = if (isCall) accentGreen else accentRed
    val formattedTime = remember(signal.timestamp) {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        sdf.format(Date(signal.timestamp))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFF2B3139)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* Feed Ripple Feedback */ }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Directional Signal Icon Badge
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(themeColor.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = if (isCall) "CALL upward trend" else "PUT downward trend",
                    tint = themeColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            // Trading parameters column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BTC/USDT",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = signal.type,
                        color = themeColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                // Extra metrics at bottom
                Text(
                    text = String.format(Locale.US, "RSI: %.2f  •  EMA: $%,.1f", signal.rsiValue, signal.emaValue),
                    color = grayText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal
                )
            }
            
            // Trigger Price and Time
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = String.format(Locale.US, "$%,.1f", signal.price),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formattedTime,
                    color = grayText,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}


