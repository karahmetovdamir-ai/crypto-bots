package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BotState
import com.example.data.SignalEntity
import com.example.data.SignalRepository
import com.example.service.SignalBotService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SignalBotViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SignalRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = SignalRepository(db.signalDao())
    }

    // Signals stream from Room db
    val signals: StateFlow<List<SignalEntity>> = repository.allSignals
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Live streams from global BotState
    val isServiceRunning: StateFlow<Boolean> = BotState.isServiceRunning
    val isWebSocketConnected: StateFlow<Boolean> = BotState.isWebSocketConnected
    val currentPrice: StateFlow<Double> = BotState.currentPrice
    val priceDirection: StateFlow<Int> = BotState.priceDirection
    val liveRsi: StateFlow<Double?> = BotState.liveRsi
    val liveEma: StateFlow<Double?> = BotState.liveEma

    fun startBot(context: Context) {
        val intent = Intent(context, SignalBotService::class.java).apply {
            action = SignalBotService.ACTION_START
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun stopBot(context: Context) {
        val intent = Intent(context, SignalBotService::class.java).apply {
            action = SignalBotService.ACTION_STOP
        }
        context.startService(intent)
    }

    fun clearLogHistory() {
        viewModelScope.launch {
            repository.clearAllSignals()
        }
    }
}
